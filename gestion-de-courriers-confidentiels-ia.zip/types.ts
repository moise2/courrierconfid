export interface CourrierData {
  objet: string;
  typeDocument: string;
  resume: string;
  provenance: string;
  // FIX: Corrected the type of 'destination' from the literal "string" to the type string.
  destination: string;
  dateArrivee: string;
  dateEdition: string;
  dateDelai: string;
  priorite: 'normale' | 'moyenne' | 'urgente' | 'très urgente';
}

export interface AiAnalysisResult {
  objet: string;
  resume: string;
  type_document: string;
  date_delai_traitement: string;
  date_arrivee: string;
  date_edition: string;
  provenance: string;
  structure_destination: string;
}