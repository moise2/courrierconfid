
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="flex-shrink-0 bg-bg-card dark:bg-dark-bg-card border-b border-border-color dark:border-dark-border-color h-16 flex items-center justify-between px-6">
      <div>
        <h1 className="text-xl font-bold text-text-dark dark:text-dark-text-dark">Tableau de Bord Général</h1>
      </div>
      <div className="flex items-center gap-4">
        <div className="relative hidden md:block">
          <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
          <input
            type="search"
            placeholder="Rechercher…"
            className="pl-10 pr-4 py-2 w-64 bg-bg-light dark:bg-dark-bg-light border border-border-color dark:border-dark-border-color rounded-full focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        <button className="h-10 w-10 rounded-full text-text-light dark:text-dark-text-light hover:bg-gray-100 dark:hover:bg-dark-border-color flex items-center justify-center">
          <i className="fas fa-bell text-xl"></i>
        </button>
        <div className="flex items-center gap-3">
          <img
            src="https://picsum.photos/40"
            alt="Photo de profil"
            className="h-10 w-10 rounded-full border-2 border-primary"
          />
          <span className="font-semibold hidden lg:block text-text-dark dark:text-dark-text-dark">Jane Doe</span>
        </div>
      </div>
    </header>
  );
};

export default Header;
