import React from 'react';

const NavLink: React.FC<{ href: string; icon: string; text: string; active?: boolean }> = ({ href, icon, text, active }) => (
  <li>
    <a
      href={href}
      className={`flex items-center gap-3 px-6 py-3 text-sm font-semibold border-l-4 transition-colors duration-200 ${
        active
          ? 'bg-primary/10 border-primary text-primary dark:text-white'
          : 'border-transparent text-gray-500 dark:text-dark-text-light hover:bg-gray-100 dark:hover:bg-dark-border-color'
      }`}
    >
      <i className={`fa-fw ${icon} w-5 h-5`}></i>
      <span>{text}</span>
    </a>
  </li>
);

const Sidebar: React.FC = () => {
  return (
    <aside className="w-64 flex-shrink-0 bg-bg-card dark:bg-dark-bg-card border-r border-border-color dark:border-dark-border-color hidden md:flex flex-col">
      <div className="h-16 flex items-center px-6 border-b border-border-color dark:border-dark-border-color">
        <i className="fas fa-lock text-primary text-2xl mr-3"></i>
        <span className="text-xl font-bold text-text-dark dark:text-dark-text-dark">Courrier IA</span>
      </div>
      <nav className="flex-1 mt-6">
        <ul>
          <NavLink href="#" icon="fas fa-tachometer-alt" text="Tableau de Bord" active />
          <NavLink href="#" icon="fas fa-chart-line" text="Analyse des Données" />
          <NavLink href="#" icon="fas fa-users" text="Gestion des Utilisateurs" />
          <NavLink href="#" icon="fas fa-folder-open" text="Documents Récents" />
          <NavLink href="#" icon="fas fa-cog" text="Paramètres" />
        </ul>
      </nav>
      <div className="mt-auto p-6 text-center text-xs text-gray-400">
        <p>Signature</p>
        <p className="font-semibold text-gray-500 dark:text-gray-300">komlaAKPAKI</p>
      </div>
    </aside>
  );
};

export default Sidebar;