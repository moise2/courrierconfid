
import React, { useState } from 'react';

interface DashboardProps {
  onOpenAiModal: () => void;
}

const KpiCard: React.FC<{ icon: string; label: string; value: string; color: string }> = ({ icon, label, value, color }) => (
  <div className={`bg-bg-card dark:bg-dark-bg-card p-5 rounded-xl shadow-sm flex items-center gap-4 border-l-4 ${color}`}>
    <div className={`h-12 w-12 rounded-full flex items-center justify-center text-white ${color.replace('border', 'bg')}`}>
      <i className={`fas ${icon} text-xl`}></i>
    </div>
    <div>
      <p className="text-sm text-text-light dark:text-dark-text-light">{label}</p>
      <h3 className="text-2xl font-bold text-text-dark dark:text-dark-text-dark">{value}</h3>
    </div>
  </div>
);

const TabButton: React.FC<{ label: string; icon: string; active: boolean; onClick: () => void }> = ({ label, icon, active, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-2 px-4 py-3 font-semibold border-b-2 transition-colors duration-200 ${
      active
        ? 'border-primary text-primary'
        : 'border-transparent text-gray-500 hover:text-primary'
    }`}
  >
    <i className={`fas ${icon}`}></i>
    <span>{label}</span>
  </button>
);

const Dashboard: React.FC<DashboardProps> = ({ onOpenAiModal }) => {
  const [activeTab, setActiveTab] = useState('recus');

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <KpiCard icon="fa-envelope" label="Courriers Arrivés" value="1,200" color="border-blue-500" />
        <KpiCard icon="fa-paper-plane" label="Courriers Départ" value="45" color="border-green-500" />
        <KpiCard icon="fa-hourglass-half" label="En Attente" value="12" color="border-yellow-500" />
        <KpiCard icon="fa-check-double" label="Total Traité" value="1,190" color="border-cyan-500" />
      </div>

      <div className="bg-bg-card dark:bg-dark-bg-card rounded-xl shadow-sm">
        <div className="border-b border-border-color dark:border-dark-border-color flex items-center justify-between">
          <div className="flex">
            <TabButton label="Courriers Reçus" icon="fa-download" active={activeTab === 'recus'} onClick={() => setActiveTab('recus')} />
            <TabButton label="Courriers Envoyés" icon="fa-upload" active={activeTab === 'envoyes'} onClick={() => setActiveTab('envoyes')} />
            <TabButton label="État du Traitement" icon="fa-tasks" active={activeTab === 'statut'} onClick={() => setActiveTab('statut')} />
          </div>
        </div>
        
        <div className="p-6">
          {activeTab === 'recus' && (
            <div>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold">Tableau des Courriers Reçus</h3>
                <button
                  onClick={onOpenAiModal}
                  className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center gap-2"
                >
                  <i className="fa-solid fa-wand-magic-sparkles"></i>
                  Enregistrer un courrier (IA)
                </button>
              </div>
              <p>Contenu du tableau des courriers reçus...</p>
            </div>
          )}
          {activeTab === 'envoyes' && (
            <div>
              <h3 className="text-lg font-bold mb-4">Tableau des Courriers Envoyés</h3>
              <p>Contenu du tableau des courriers envoyés...</p>
            </div>
          )}
          {activeTab === 'statut' && (
            <div>
              <h3 className="text-lg font-bold mb-4">Récapitulatif de l'État de Traitement</h3>
              <p>Contenu du récapitulatif de l'état de traitement...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
