import React, { useState, useCallback, ChangeEvent } from 'react';
import type { CourrierData } from '../types';
import { analyzeDocument } from '../services/geminiService';

interface AiModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: CourrierData) => void;
}

const AiModal: React.FC<AiModalProps> = ({ isOpen, onClose, onSave }) => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [statusText, setStatusText] = useState('');
  const [formData, setFormData] = useState<CourrierData>({
    objet: '',
    typeDocument: '',
    resume: '',
    provenance: '',
    destination: '',
    dateArrivee: '',
    dateEdition: '',
    dateDelai: '',
    priorite: 'normale',
  });

  const resetState = () => {
    setFile(null);
    setPreview(null);
    setIsLoading(false);
    setStatusText('');
    setFormData({
      objet: '', typeDocument: '', resume: '', provenance: '', destination: '',
      dateArrivee: '', dateEdition: '', dateDelai: '', priorite: 'normale',
    });
  }

  const handleClose = () => {
    resetState();
    onClose();
  };
  
  const handleFileChange = useCallback(async (e: ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    setFile(selectedFile);

    if (preview) URL.revokeObjectURL(preview);
    const previewUrl = URL.createObjectURL(selectedFile);
    setPreview(previewUrl);

    setIsLoading(true);
    setStatusText('Analyse du document en cours...');

    try {
      const reader = new FileReader();
      reader.readAsDataURL(selectedFile);
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        const mimeType = selectedFile.type;

        const result = await analyzeDocument(base64Data, mimeType);
        
        setFormData(prev => ({
          ...prev,
          objet: result.objet || '',
          resume: result.resume || '',
          typeDocument: result.type_document || '',
          dateDelai: result.date_delai_traitement || '',
          dateArrivee: result.date_arrivee || '',
          dateEdition: result.date_edition || '',
          provenance: result.provenance || '',
          destination: result.structure_destination || '',
        }));

        setStatusText('Analyse terminée. Veuillez vérifier les champs.');
        setIsLoading(false);
      };
      reader.onerror = () => {
          throw new Error("Erreur de lecture du fichier.");
      };
    } catch (error) {
      console.error("Erreur d'analyse IA:", error);
      setStatusText('Une erreur est survenue lors de l\'analyse.');
      setIsLoading(false);
    }
  }, [preview]);
  
  const handleFormChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    handleClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-bg-card dark:bg-dark-bg-card rounded-2xl shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col relative overflow-hidden">
        <header className="flex items-center justify-between p-4 border-b border-border-color dark:border-dark-border-color flex-shrink-0">
          <h2 className="text-lg font-bold">Enregistrer un courrier avec IA</h2>
          <button onClick={handleClose} className="h-8 w-8 rounded-full hover:bg-gray-200 dark:hover:bg-dark-border-color flex items-center justify-center">&times;</button>
        </header>
        
        <div className="flex-1 overflow-y-auto p-6">
          <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Panel: File Preview */}
            <div className="flex flex-col gap-4">
              <div className="relative aspect-square lg:aspect-[3/4] border-2 border-dashed border-gray-300 dark:border-dark-border-color rounded-lg flex items-center justify-center bg-gray-50 dark:bg-dark-bg-light overflow-hidden">
                {isLoading && (
                   <div className="absolute inset-0 bg-white/80 dark:bg-black/80 flex flex-col items-center justify-center z-10">
                      <i className="fas fa-spinner fa-spin text-4xl text-primary mb-4"></i>
                      <p className="font-semibold">{statusText}</p>
                   </div>
                )}
                {preview ? (
                  <img src={preview} alt="Aperçu du document" className="object-contain w-full h-full" />
                ) : (
                  <div className="text-center text-gray-500">
                    <i className="fas fa-file-alt text-5xl mb-2"></i>
                    <p>Aucun aperçu disponible</p>
                  </div>
                )}
              </div>
              <div className="flex-shrink-0 grid grid-cols-2 gap-2">
                <label htmlFor="file-upload" className="w-full cursor-pointer bg-blue-500 text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 hover:bg-blue-600 transition-colors">
                  <i className="fas fa-upload"></i>
                  <span>Importer un Fichier</span>
                </label>
                <input id="file-upload" type="file" className="hidden" onChange={handleFileChange} accept="image/png, image/jpeg, image/webp, application/pdf" />

                <label htmlFor="camera-upload" className="w-full cursor-pointer bg-green-500 text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 hover:bg-green-600 transition-colors">
                  <i className="fas fa-camera"></i>
                  <span>Scanner (Mobile)</span>
                </label>
                <input id="camera-upload" type="file" className="hidden" onChange={handleFileChange} accept="image/*" capture="environment" />

              </div>
               <p className="text-xs text-center mt-2 text-gray-500 col-span-2">{statusText || "Importez un document ou scannez-le avec votre mobile."}</p>
            </div>

            {/* Right Panel: Form */}
            <div className="space-y-4">
               <FormField label="Objet / Titre" required><Input name="objet" value={formData.objet} onChange={handleFormChange} /></FormField>
               <div className="grid grid-cols-2 gap-4">
                 <FormField label="Type de document"><Input name="typeDocument" value={formData.typeDocument} onChange={handleFormChange} /></FormField>
                 <FormField label="Provenance"><Input name="provenance" value={formData.provenance} onChange={handleFormChange} /></FormField>
               </div>
               <FormField label="Résumé"><Textarea name="resume" value={formData.resume} onChange={handleFormChange} rows={4} /></FormField>
               <FormField label="Structure de Destination"><Input name="destination" value={formData.destination} onChange={handleFormChange} /></FormField>
                <div className="grid grid-cols-2 gap-4">
                  <FormField label="Date d'arrivée"><Input type="date" name="dateArrivee" value={formData.dateArrivee} onChange={handleFormChange} /></FormField>
                  <FormField label="Date d'édition"><Input type="date" name="dateEdition" value={formData.dateEdition} onChange={handleFormChange} /></FormField>
                </div>
                <div className="grid grid-cols-2 gap-4">
                 <FormField label="Délai de traitement"><Input type="date" name="dateDelai" value={formData.dateDelai} onChange={handleFormChange} /></FormField>
                  <FormField label="Priorité">
                    <Select name="priorite" value={formData.priorite} onChange={handleFormChange}>
                      <option value="normale">Normale</option>
                      <option value="moyenne">Moyenne</option>
                      <option value="urgente">Urgente</option>
                      <option value="très urgente">Très urgente</option>
                    </Select>
                  </FormField>
                </div>
            </div>
          </form>
        </div>

        <footer className="flex-shrink-0 p-4 border-t border-border-color dark:border-dark-border-color flex justify-end gap-4 bg-gray-50 dark:bg-dark-bg-card/50">
          <button onClick={handleClose} className="px-4 py-2 rounded-lg bg-gray-200 dark:bg-dark-border-color hover:bg-gray-300 dark:hover:bg-gray-600 font-semibold">Annuler</button>
          <button onClick={handleSubmit} disabled={isLoading || !file} className="px-6 py-2 rounded-lg bg-primary text-white font-bold hover:bg-primary-dark disabled:bg-gray-400 disabled:cursor-not-allowed">
            <i className="fas fa-save mr-2"></i> Enregistrer
          </button>
        </footer>
      </div>
    </div>
  );
};

// Form field components for cleaner JSX
const FormField: React.FC<{ label: string; children: React.ReactNode; required?: boolean }> = ({ label, children, required }) => (
  <div>
    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{label} {required && <span className="text-red-500">*</span>}</label>
    {children}
  </div>
);

const Input = (props: React.ComponentProps<'input'>) => (
  <input {...props} className="w-full px-3 py-2 border border-gray-300 dark:border-dark-border-color rounded-md shadow-sm focus:ring-primary focus:border-primary bg-bg-card dark:bg-dark-bg-card" />
);

const Textarea = (props: React.ComponentProps<'textarea'>) => (
  <textarea {...props} className="w-full px-3 py-2 border border-gray-300 dark:border-dark-border-color rounded-md shadow-sm focus:ring-primary focus:border-primary bg-bg-card dark:bg-dark-bg-card" />
);

const Select = (props: React.ComponentProps<'select'>) => (
  <select {...props} className="w-full px-3 py-2 border border-gray-300 dark:border-dark-border-color rounded-md shadow-sm focus:ring-primary focus:border-primary bg-bg-card dark:bg-dark-bg-card" />
);


export default AiModal;