
import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import AiModal from './components/AiModal';
import type { CourrierData } from './types';

const App: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleSaveCourrier = (data: CourrierData) => {
    console.log("Courrier enregistré:", data);
    // Here you would typically add the new mail to your state
    // For this demo, we just log it.
    setIsModalOpen(false);
  };

  return (
    <div className="flex h-screen bg-bg-light dark:bg-dark-bg-light font-sans">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-x-hidden overflow-y-auto p-4 md:p-8">
          <Dashboard onOpenAiModal={() => setIsModalOpen(true)} />
        </main>
      </div>
      <AiModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveCourrier}
      />
    </div>
  );
};

export default App;
