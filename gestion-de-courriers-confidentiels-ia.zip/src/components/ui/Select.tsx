import React from 'react';

export const Select = (props: React.ComponentProps<'select'>) => (
  <select {...props} className="w-full px-3 py-2 border border-gray-300 dark:border-dark-border-color rounded-md shadow-sm focus:ring-primary focus:border-primary bg-bg-card dark:bg-dark-bg-card" />
);