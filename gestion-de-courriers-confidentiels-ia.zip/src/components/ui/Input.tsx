import React from 'react';

export const Input = (props: React.ComponentProps<'input'>) => (
  <input {...props} className="w-full px-3 py-2 border border-gray-300 dark:border-dark-border-color rounded-md shadow-sm focus:ring-primary focus:border-primary bg-bg-card dark:bg-dark-bg-card file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" />
);