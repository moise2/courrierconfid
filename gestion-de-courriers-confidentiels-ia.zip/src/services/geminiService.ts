import { GoogleGenAI, Type } from "@google/genai";
import type { AiAnalysisResult } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    objet: {
      type: Type.STRING,
      description: "L'objet ou le titre principal du document.",
    },
    resume: {
      type: Type.STRING,
      description: "Un résumé concis du contenu du document en 2-3 phrases.",
    },
    type_document: {
      type: Type.STRING,
      description: "Le type de document (ex: 'Arrêté', 'Lettre d'information', 'Facture', 'Rapport').",
    },
    date_delai_traitement: {
      type: Type.STRING,
      description: "La date limite de traitement mentionnée, au format AAAA-MM-JJ. Laisser vide si non spécifié.",
    },
    date_arrivee: {
      type: Type.STRING,
      description: "La date de réception du courrier, au format AAAA-MM-JJ. Si non spécifiée, utiliser la date du jour.",
    },
    date_edition: {
      type: Type.STRING,
      description: "La date de création ou d'édition du document, au format AAAA-MM-JJ. Laisser vide si non spécifié.",
    },
    provenance: {
      type: Type.STRING,
      description: "L'expéditeur ou l'organisation d'origine du courrier.",
    },
    structure_destination: {
      type: Type.STRING,
      description: "Le destinataire ou le service de destination du courrier.",
    },
  },
  required: ["objet", "resume", "type_document", "provenance", "structure_destination"]
};

export async function analyzeDocument(base64Data: string, mimeType: string): Promise<AiAnalysisResult> {
  const today = new Date().toISOString().split('T')[0]; // AAAA-MM-JJ

  const prompt = `Analyse l'image de ce document confidentiel et extrais les informations suivantes. La date d'aujourd'hui est ${today}. Pour la date d'arrivée, si elle n'est pas explicitement mentionnée, utilise la date d'aujourd'hui. Réponds uniquement avec le JSON structuré demandé.`;

  const imagePart = {
    inlineData: {
      data: base64Data,
      mimeType: mimeType,
    },
  };

  const textPart = {
    text: prompt,
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
      },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as AiAnalysisResult;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to analyze document with Gemini API.");
  }
}