export interface CourrierData {
  objet: string;
  typeDocument: string;
  autreTypeDocument?: string;
  resume: string;
  provenance: string;
  destination: string;
  dateArrivee: string;
  dateEdition: string;
  dateDelai: string;
  priorite: 'normale' | 'moyenne' | 'urgente' | 'très urgente';
  commentaire?: string;
  hasAutreFichier: boolean; // Champ pour la case à cocher
  support?: 'electronique' | 'cle_usb' | 'cd' | 'autre';
  autreSupport?: string;
  autreFichier?: File | null;
}

export interface AiAnalysisResult {
  objet: string;
  resume: string;
  type_document: string;
  date_delai_traitement: string;
  date_arrivee: string;
  date_edition: string;
  provenance: string;
  structure_destination: string;
}