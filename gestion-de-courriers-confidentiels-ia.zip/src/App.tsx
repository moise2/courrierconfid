import React, { useState } from 'react';
import Sidebar from './features/Layout/Sidebar';
import Header from './features/Layout/Header';
import Dashboard from './features/Dashboard/Dashboard';
import AiModal from './features/Courrier/AiModal';
import type { CourrierData } from './types';

const App: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleSaveCourrier = (data: CourrierData) => {
    console.log("Courrier enregistré:", data);
    // Ici, vous ajouteriez normalement le nouveau courrier à votre état
    // Pour cette démo, nous ne faisons que le logger.
    setIsModalOpen(false);
  };

  return (
    <div className="flex h-screen bg-bg-light dark:bg-dark-bg-light font-sans">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-x-hidden overflow-y-auto p-4 md:p-8">
          <Dashboard onOpenAiModal={() => setIsModalOpen(true)} />
        </main>
      </div>
      <AiModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveCourrier}
      />
    </div>
  );
};

export default App;