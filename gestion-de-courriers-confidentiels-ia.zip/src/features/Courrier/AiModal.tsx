import React, { useState, useCallback, ChangeEvent, useEffect } from 'react';
import type { CourrierData } from '../../types';
import { analyzeDocument } from '../../services/geminiService';
import { FormField } from '../../components/ui/FormField';
import { Input } from '../../components/ui/Input';
import { Textarea } from '../../components/ui/Textarea';
import { Select } from '../../components/ui/Select';

interface AiModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: CourrierData) => void;
}

const documentTypes = ["Arrêté", "Lettre d'information", "Facture", "Rapport", "Note de service", "Compte rendu", "Contrat"];

const initialFormData: CourrierData = {
  objet: '',
  typeDocument: '',
  autreTypeDocument: '',
  resume: '',
  provenance: '',
  destination: '',
  dateArrivee: '',
  dateEdition: '',
  dateDelai: '',
  priorite: 'normale',
  commentaire: '',
  hasAutreFichier: false,
  support: 'electronique',
  autreSupport: '',
  autreFichier: null,
};

const AiModal: React.FC<AiModalProps> = ({ isOpen, onClose, onSave }) => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [statusText, setStatusText] = useState('');
  const [isMobileDevice, setIsMobileDevice] = useState(false);
  const [formData, setFormData] = useState<CourrierData>(initialFormData);

  useEffect(() => {
    const mobileCheck = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    setIsMobileDevice(mobileCheck);
  }, []);

  const resetState = useCallback(() => {
    setFile(null);
    if (preview) {
        URL.revokeObjectURL(preview);
    }
    setPreview(null);
    setIsLoading(false);
    setStatusText('');
    setFormData(initialFormData);
  }, [preview]);

  const handleClose = useCallback(() => {
    resetState();
    onClose();
  }, [resetState, onClose]);
  
  const handleFileChange = useCallback(async (e: ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    setFile(selectedFile);

    if (preview) URL.revokeObjectURL(preview);
    const previewUrl = URL.createObjectURL(selectedFile);
    setPreview(previewUrl);

    setIsLoading(true);
    setStatusText('Analyse du document en cours...');

    try {
      const reader = new FileReader();
      reader.readAsDataURL(selectedFile);
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        const mimeType = selectedFile.type;

        const result = await analyzeDocument(base64Data, mimeType);
        
        const aiDocType = result.type_document || '';
        const knownType = documentTypes.find(type => aiDocType.toLowerCase().includes(type.toLowerCase()));

        setFormData(prev => ({
          ...prev,
          objet: result.objet || '',
          resume: result.resume || '',
          typeDocument: knownType ? knownType : 'Autre',
          autreTypeDocument: knownType ? '' : aiDocType,
          dateDelai: result.date_delai_traitement || '',
          dateArrivee: result.date_arrivee || '',
          dateEdition: result.date_edition || '',
          provenance: result.provenance || '',
          destination: result.structure_destination || '',
        }));

        setStatusText('Analyse terminée. Veuillez vérifier les champs.');
        setIsLoading(false);
      };
      reader.onerror = () => { throw new Error("Erreur de lecture du fichier."); };
    } catch (error) {
      console.error("Erreur d'analyse IA:", error);
      setStatusText('Une erreur est survenue lors de l\'analyse.');
      setIsLoading(false);
    }
  }, [preview]);
  
  const handleFormChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
     
    if (type === 'checkbox') {
        const checked = (e.target as HTMLInputElement).checked;
        setFormData(prev => {
            const newState = { ...prev, [name]: checked };
            if (!checked) {
                // Réinitialise les champs liés si la case est décochée
                newState.support = 'electronique';
                newState.autreSupport = '';
                newState.autreFichier = null;
            }
            return newState;
        });
    } else if (type === 'file') {
        const files = (e.target as HTMLInputElement).files;
        setFormData(prev => ({ ...prev, [name]: files ? files[0] : null }));
    } else {
        setFormData(prev => {
            const newState = { ...prev, [name]: value };
            // Si l'utilisateur change le type de document et que ce n'est pas 'Autre', on vide le champ personnalisé
            if (name === 'typeDocument' && value !== 'Autre') {
                newState.autreTypeDocument = '';
            }
            return newState;
        });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    handleClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-bg-card dark:bg-dark-bg-card rounded-2xl shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col relative overflow-hidden">
        <header className="flex items-center justify-between p-4 border-b border-border-color dark:border-dark-border-color flex-shrink-0">
          <h2 className="text-lg font-bold">Enregistrer un courrier avec IA</h2>
          <button onClick={handleClose} className="h-8 w-8 rounded-full hover:bg-gray-200 dark:hover:bg-dark-border-color flex items-center justify-center" aria-label="Fermer">&times;</button>
        </header>
        
        <div className="flex-1 overflow-y-auto p-6">
          <form id="courier-form" onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Panneau Gauche: Aperçu du fichier et actions */}
            <div className="flex flex-col gap-4">
              <div className="relative aspect-square lg:aspect-[3/4] border-2 border-dashed border-gray-300 dark:border-dark-border-color rounded-lg flex items-center justify-center bg-gray-50 dark:bg-dark-bg-light overflow-hidden">
                {isLoading && (
                   <div className="absolute inset-0 bg-white/80 dark:bg-black/80 flex flex-col items-center justify-center z-10">
                      <i className="fas fa-spinner fa-spin text-4xl text-primary mb-4"></i>
                      <p className="font-semibold">{statusText}</p>
                   </div>
                )}
                {preview ? ( <img src={preview} alt="Aperçu du document" className="object-contain w-full h-full" /> ) : (
                  <div className="text-center text-gray-500"><i className="fas fa-file-alt text-5xl mb-2"></i><p>Aucun aperçu disponible</p></div>
                )}
              </div>
              <div className="flex-shrink-0">
                {isMobileDevice ? (
                  <div className="grid grid-cols-2 gap-2">
                    <label htmlFor="file-upload" className="w-full cursor-pointer bg-blue-500 text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 hover:bg-blue-600 transition-colors">
                      <i className="fas fa-upload"></i><span>Importer Fichier</span>
                    </label>
                    <label htmlFor="camera-upload" className="w-full cursor-pointer bg-green-500 text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 hover:bg-green-600 transition-colors">
                      <i className="fas fa-camera"></i><span>Scanner</span>
                    </label>
                    <input id="camera-upload" type="file" className="hidden" onChange={handleFileChange} accept="image/*" capture="environment" />
                  </div>
                ) : (
                  <label htmlFor="file-upload" className="w-full cursor-pointer bg-primary text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 hover:bg-primary-dark transition-colors">
                    <i className="fas fa-upload"></i><span>Importer un Fichier</span>
                  </label>
                )}
                <input id="file-upload" type="file" className="hidden" onChange={handleFileChange} accept="image/png, image/jpeg, image/webp, application/pdf" />
              </div>
              <p className="text-xs text-center text-gray-500">
                {statusText || (isMobileDevice ? "Importez un document ou scannez-le." : "Veuillez numériser votre document, puis importez le fichier.")}
              </p>
            </div>

            {/* Panneau Droit: Formulaire */}
            <div className="space-y-4">
               <FormField label="Objet / Titre" required><Input name="objet" value={formData.objet} onChange={handleFormChange} required /></FormField>
               
               <div className="grid grid-cols-2 gap-4">
                 <FormField label="Type de document">
                    <Select name="typeDocument" value={formData.typeDocument} onChange={handleFormChange}>
                        <option value="" disabled>Sélectionner un type</option>
                        {documentTypes.map(type => <option key={type} value={type}>{type}</option>)}
                        <option value="Autre">Autre</option>
                    </Select>
                 </FormField>
                 <FormField label="Provenance"><Input name="provenance" value={formData.provenance} onChange={handleFormChange} /></FormField>
               </div>
               
               {formData.typeDocument === 'Autre' && (
                <div className="animate-fade-in">
                    <FormField label="Préciser le type de document">
                        <Input name="autreTypeDocument" value={formData.autreTypeDocument || ''} onChange={handleFormChange} placeholder="Spécifier le type de document..." />
                    </FormField>
                </div>
               )}

               <FormField label="Résumé"><Textarea name="resume" value={formData.resume} onChange={handleFormChange} rows={3} /></FormField>
               <FormField label="Structure de Destination"><Input name="destination" value={formData.destination} onChange={handleFormChange} /></FormField>
                <div className="grid grid-cols-2 gap-4">
                  <FormField label="Date d'arrivée"><Input type="date" name="dateArrivee" value={formData.dateArrivee} onChange={handleFormChange} /></FormField>
                  <FormField label="Date d'édition"><Input type="date" name="dateEdition" value={formData.dateEdition} onChange={handleFormChange} /></FormField>
                </div>
                <div className="grid grid-cols-2 gap-4">
                 <FormField label="Délai de traitement"><Input type="date" name="dateDelai" value={formData.dateDelai} onChange={handleFormChange} /></FormField>
                  <FormField label="Priorité">
                    <Select name="priorite" value={formData.priorite} onChange={handleFormChange}>
                      <option value="normale">Normale</option><option value="moyenne">Moyenne</option><option value="urgente">Urgente</option><option value="très urgente">Très urgente</option>
                    </Select>
                  </FormField>
                </div>
                 <FormField label="Commentaire"><Textarea name="commentaire" value={formData.commentaire} onChange={handleFormChange} rows={2} placeholder="Ajouter une note..." /></FormField>
                 
                 <div className="flex items-center gap-2 pt-2">
                    <input
                        type="checkbox"
                        id="hasAutreFichier"
                        name="hasAutreFichier"
                        checked={formData.hasAutreFichier}
                        onChange={handleFormChange}
                        className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                    />
                    <label htmlFor="hasAutreFichier" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        Autre (joindre un fichier ou support supplémentaire)
                    </label>
                 </div>

                 {formData.hasAutreFichier && (
                    <div className="border border-gray-300 dark:border-dark-border-color rounded-lg p-4 space-y-4 animate-fade-in">
                        <FormField label="Type de support">
                            <Select name="support" value={formData.support} onChange={handleFormChange}>
                                <option value="electronique">Électronique</option><option value="cle_usb">Clé USB</option><option value="cd">CD</option><option value="autre">Autre</option>
                            </Select>
                        </FormField>
                        {formData.support === 'autre' && (
                            <FormField label="Préciser le support">
                                <Input name="autreSupport" value={formData.autreSupport} onChange={handleFormChange} placeholder="Ex: Disque dur externe" />
                            </FormField>
                        )}
                        <FormField label="Sélectionner le fichier">
                            <Input name="autreFichier" type="file" onChange={handleFormChange} />
                        </FormField>
                    </div>
                 )}
            </div>
          </form>
        </div>

        <footer className="flex-shrink-0 p-4 border-t border-border-color dark:border-dark-border-color flex justify-end gap-4 bg-gray-50 dark:bg-dark-bg-card/50">
          <button type="button" onClick={handleClose} className="px-4 py-2 rounded-lg bg-gray-200 dark:bg-dark-border-color hover:bg-gray-300 dark:hover:bg-gray-600 font-semibold">Annuler</button>
          <button form="courier-form" type="submit" disabled={isLoading || !file} className="px-6 py-2 rounded-lg bg-primary text-white font-bold hover:bg-primary-dark disabled:bg-gray-400 disabled:cursor-not-allowed">
            <i className="fas fa-save mr-2"></i> Enregistrer
          </button>
        </footer>
      </div>
    </div>
  );
};

export default AiModal;